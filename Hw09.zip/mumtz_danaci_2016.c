									/*MÜMTAZ DANACI*/
									/*    HW09     */
									/* 161044002*/
#include <stdio.h>
#include <time.h>		/*ilk dört satırda gerekli olan kütüphaneleri ekledim.*/
#include <stdlib.h>		
#include <math.h>
int main(){		
		
		srand(time(NULL));    /*her seferinde rastgele değer atayabilmesi için kullandım*/
		int p,toplam2=0,toplam1=0, toplam3=0, carpim1=1, carpim2=1;/*tanımlaığım integer değerleri*/
		double kok=0, toplam5=0,  toplam4=0,  carpim3=1, sonuc, carpim4=1;/*double değerlerim*/
		int v1[20];		/*v1 vektörüm,arrayim*/
		int v2[20];		/*v2 vektörüm*/
		int v3[20];		/*1.ve 2. vektörlerin toplamı*/
		for(p=0;p<20;p++){		/*v1 vektörü için açtığım for*/
			v1[p]=rand()%10;	/*v1 vektörüne rastgele değerler vermek için kullanıdığım satır.*/
			printf("%d,",v1[p]);/*v1 vektörünü ekrana yazdırdım.*/
				if(v1[p]!=0)		/*değeri sıfır olmayan değerleri toplam1 integerine atadım.*/
					toplam1++;
			}
		printf("\n");
		printf("v1 L0 norm:%d\n",toplam1); /*değeri sıfır olmayan değerleri(L0'ları) verilen formatta ekrana yadırdım*/
		for(p=0;p<20;p++){	/*v2 vektörü için açtığım for*/
			v2[p]=rand()%10;		/*v2 vektörüne rastgele değerler vermek için kullanıdığım satır.*/
			printf("%d,",v2[p]);	/*v2 vektörünü ekrana yazdırdım.*/
			
			if(v2[p]!=0)		/*değeri sıfır olmayan değerleri toplam2 integerine atadım.*/
				toplam2++;
		}
		printf("\n");
		printf("v2 L0 norm:%d\n",toplam2); /*değeri sıfır olmayan değerleri(L0'ları) verilen formatta ekrana yadırdım*/
		printf("v1 + v2 ="); 
		for(p=0;p<19;p++){	/*bu for içerisinde v1 ile v2 nin karşılıklı elemanlarını topladım*/
			v3[p]=v1[p]+v2[p];		/*bu v3 içerisine attım*/
			printf("%d,",v3[p]);	/*v3 ü ekrana yazdırdım.*/
			}
			printf("%d",v3[19]);
			printf("\n");
		for(p=0;p<20;p++){			/*iç çarpım içerinde yapacağım , karşılıklı çarpma işlemini bu for içerinde yaptım.*/
			carpim1=v1[p]*v2[p];
			toplam3=toplam3+carpim1;		/*çarpımları toplam3 havuzunda topladım*/
		}
		for(p=0;p<20;p++){			/*v1 vektörünün uzunluğuna ulaşmak için karalerini aldım.*/
			carpim2=v1[p]*v1[p];
			toplam4=toplam4+carpim2;	/* karelerini aldığım v1 değerlerini toplam4 havuzunda topladım.*/
			}
	/*	printf("d1=>%lf\n",toplam4); v1'in uzunluğunu ekrana yazdıran satır	*/	
		for(p=0;p<20;p++){			/*v2 vektörünün uzunluğuna ulaşmak için karalerini aldım.*/
			carpim3=v2[p]*v2[p];
			toplam5=toplam5+carpim3;	/* karelerini aldığım v1 değerlerini toplam5 havuzunda topladım.*/
		}
	/*	printf("d2=>%lf\n",toplam5); v2 uzunluğunu ekrana yazdırır.	*/		
		carpim4=toplam4*toplam5; /*iç çarpımda paydadaki işlemleri yaptım. uzunlukları çarptım*/ 
		kok=sqrt(carpim4);		/*çarpım4 ünkök alma işlemini yaptım.formulde verildiği üzere*/		
		sonuc=toplam3/kok;		/*son olarak bölme işlemini yaptım.*/
		printf("sim(v1,v2):%lf\n",sonuc);		/*vee ekrana yazdırdım.*/
	return 0;
}
