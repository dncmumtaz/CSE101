                        /* MÜMTAZ DANACI            */
                        /*161044002   HW06(II)      */
                        /*1 girildiğidiğinde elmas çizdiren; */
                        /*2 girildiğinde öğrenci bilgisi gösteren; */
                        /*0 girildiğinde ise çıkış yapan bir programdır.  */
#include <stdio.h>
int main (){
		int i,n, p=1, j, k;
		while(p!=0){                           /* yukarıda p değerini 1 olarak belirledim ve bu değer 0 olana */
		 printf("--- MENU ---\n");             /* kadar while dögüsünün devam etmesini istiyorum*/     
		 printf("1. Yıldızlardan elmas ciz\n");  /*11.,12.,13.,14.,15.,16. satırlarda ekrana parantez içersin- */
		 printf("2. Ogrenci bilgisini goster\n"); /* deki metinleri yazdırdım alt alta.*/ 
		 printf("0. Cikis\n\n");
		 printf("Seceneginiz:\n");
		 scanf("%d",&n);		 
		 	if(n==1){                           /*if else 1. , 2. , 0. durumları incelemek için kullandım */ 
			int yilmik, yuksek, yuk, ass, i, k, b,bosmik;  /*integerları tanımladım yilmik=yildiz miktari */
			printf("yükseklik gir\n");      /*kullanıcıdan yukseklik girmsini istedim*/
			scanf("%d",&yuksek);       		/*kullanıcının atadığı değeri adresten aldım*/
			bosmik=(yuksek-1)/2;     /*bosluk mitarı==bosmik'i yuksekliğin bir eksiğinin yarısı olarak atadım*/
			yilmik=1;	  /*çünkü ilk satırdaki bosluk mikatarını bu şekilde belirledim ö: 5ise bosmik==2*/ 
			yuk=(yuksek+1)/2; /*yuk ifadesi elmasın YUKARI bölümünün temsiliyetidir.*/
			ass=yuksek-yuk;		/*ass elmasın AŞŞAĞI bolumunu temsil etmektedir*/			
				for (b=0; b<yuk; b++ ){      /*ilk üç for yapısını elmasın üst kısmı için kullandım*/
		                           /* bu yüzden yüksekliği iki farklı integer ile tekrar kullandım.*/ 
					for ( k=0; k<bosmik; k++) /*k bosmik'e ulaşana kadar boşluk yerleştirecek */ 
											{
						printf(" ");
											}
					for(i=0;i<yilmik; i++)    /*i yilmik'e ulaşana kadar yıldız yerleştirecek*/
										{
						printf("*");
										}
       			yilmik=yilmik+2;  /*yildiz miktarı şekilde iki iki arttırıldığı için yilmiki iki artırdım.*/
				bosmik--;         /*bosmik sekilde bir bir azaldığı için bir bir azalttım.*/
				printf("\n");    /*her seferinde alt satıra geçmesi için \n kullandım.*/
		}
				for (b=0; b<ass; b++ )   /*bu üç for ise elmasın alt bölümü için */
										{
					for ( k=0; k<bosmik+2; k++)/*bosmik'2 arttırdım çünkü alt kısmın ilk satırında bosluk*/
					{ /*miktarı üst bölümde sondan bir önceki satırın bosluk miktarına eşit olmalıdır*/
						printf(" ");
												}
					for(i=0;i<yilmik-4; i++)  /*yıldızın periyodik bir şekilde azalmasını sağlayan satır*/
											{
						printf("*");
											}
        		yilmik=yilmik-2; /*yildiz miktarı şekilde iki iki azaltıldığı için yilmiki iki azalttım.*/
				bosmik++; /*bosmik sekilde bir bir arttığı için bir bir artırdım.*/
				printf("\n"); /*her seferinde alt satıra geçmesi için \n kullandım.*/
		}
		}
			else if(n==2){  /*55.,56.,57.,58. satırda ödevde istenen ad soyad numara bölümünü gerçekleştirdir.*/
				printf("MÜMTAZ\n");
				printf("DANACI\n");
				printf("161044002\n");
		}
			else{       /*bu kısımda ise başka durumlar pnin bir azaltılıp while'n dönmemesinini sağladım.*/
				p--;
		}		
		}
return 0;
}		 	
	 
		
		
